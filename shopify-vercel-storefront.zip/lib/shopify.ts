const domain = process.env.SHOPIFY_STORE_DOMAIN!;
const token = process.env.SHOPIFY_STOREFRONT_ACCESS_TOKEN!;

export type Product = {
  id: string;
  handle: string;
  title: string;
  description: string;
  featuredImage?: { url: string; altText?: string | null };
  priceRange: { minVariantPrice: { amount: string; currencyCode: string } };
};

export async function shopifyFetch<T>(query: string, variables: Record<string, unknown> = {}) {
  if (!domain || !token) throw new Error("Missing Shopify Storefront API environment variables.");

  const res = await fetch(`https://${domain}/api/2025-10/graphql.json`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Shopify-Storefront-Access-Token": token
    },
    body: JSON.stringify({ query, variables }),
    next: { revalidate: 60 }
  });

  if (!res.ok) throw new Error(`Shopify request failed: ${res.status}`);
  const json = await res.json();
  if (json.errors) throw new Error(json.errors[0]?.message || "Shopify API error");
  return json.data as T;
}

export async function getProducts(): Promise<Product[]> {
  const data = await shopifyFetch<{ products: { nodes: Product[] } }>(`
    query Products {
      products(first: 24, sortKey: UPDATED_AT, reverse: true) {
        nodes {
          id
          handle
          title
          description
          featuredImage { url altText }
          priceRange { minVariantPrice { amount currencyCode } }
        }
      }
    }
  `);
  return data.products.nodes;
}

export async function getProduct(handle: string): Promise<Product | null> {
  const data = await shopifyFetch<{ product: Product | null }>(`
    query Product($handle: String!) {
      product(handle: $handle) {
        id
        handle
        title
        description
        featuredImage { url altText }
        priceRange { minVariantPrice { amount currencyCode } }
      }
    }
  `, { handle });
  return data.product;
}