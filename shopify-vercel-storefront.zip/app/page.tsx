import Link from "next/link";
import { getProducts } from "../lib/shopify";
import ProductCard from "../components/ProductCard";

export default async function Home() {
  const products = await getProducts();

  return (
    <main>
      <section className="hero">
        <div>
          <p className="eyebrow">SMART • SIMPLE • MODERN</p>
          <h1>Better tech.<br/><em>Better everyday.</em></h1>
          <p className="hero-copy">Discover useful gadgets and clever accessories designed to make everyday life easier.</p>
          <Link className="button" href="/shop">Shop the collection</Link>
        </div>
      </section>

      <section className="section">
        <div className="section-head">
          <div>
            <p className="eyebrow">CURATED FOR YOU</p>
            <h2>Trending now</h2>
          </div>
          <Link href="/shop" className="text-link">View all →</Link>
        </div>
        <div className="grid">
          {products.slice(0, 8).map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>

      <section className="banner">
        <p className="eyebrow">NEW DROPS</p>
        <h2>Small upgrades.<br/>Big difference.</h2>
        <Link className="button light" href="/shop">Explore products</Link>
      </section>
    </main>
  );
}