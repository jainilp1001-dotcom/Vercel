import type { Metadata } from "next";
import "./globals.css";
import Header from "../components/Header";

export const metadata: Metadata = {
  title: "NOVA+ — Smart finds for everyday life",
  description: "A modern electronics and lifestyle storefront."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <Header />
        {children}
        <footer>© {new Date().getFullYear()} NOVA+. All rights reserved.</footer>
      </body>
    </html>
  );
}