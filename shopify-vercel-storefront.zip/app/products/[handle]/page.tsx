import { getProduct } from "../../../lib/shopify";
import Image from "next/image";
import { notFound } from "next/navigation";

export default async function ProductPage({ params }: { params: Promise<{ handle: string }> }) {
  const { handle } = await params;
  const product = await getProduct(handle);
  if (!product) notFound();

  const price = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: product.priceRange.minVariantPrice.currencyCode
  }).format(Number(product.priceRange.minVariantPrice.amount));

  return (
    <main className="product-page">
      <div className="product-image">
        {product.featuredImage && <Image src={product.featuredImage.url} alt={product.featuredImage.altText || product.title} fill sizes="50vw" />}
      </div>
      <div className="product-copy">
        <p className="eyebrow">FEATURED PRODUCT</p>
        <h1>{product.title}</h1>
        <div className="price">{price}</div>
        <p className="description">{product.description}</p>
        <a className="button full" href={`https://${process.env.SHOPIFY_STORE_DOMAIN}/products/${product.handle}`}>Buy on Shopify →</a>
        <p className="muted small">Secure checkout powered by Shopify.</p>
      </div>
    </main>
  );
}