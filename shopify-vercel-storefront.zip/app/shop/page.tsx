import { getProducts } from "../../lib/shopify";
import ProductCard from "../../components/ProductCard";

export default async function Shop() {
  const products = await getProducts();
  return (
    <main className="section shop-page">
      <p className="eyebrow">THE COLLECTION</p>
      <h1>Shop all</h1>
      <p className="muted">Useful tech and everyday accessories.</p>
      <div className="grid">{products.map((p) => <ProductCard key={p.id} product={p} />)}</div>
    </main>
  );
}