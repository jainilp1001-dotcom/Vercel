import Link from "next/link";
import { ShoppingBag, Search } from "lucide-react";

export default function Header() {
  return (
    <header className="header">
      <Link href="/" className="logo">NOVA<span>+</span></Link>
      <nav>
        <Link href="/">Home</Link>
        <Link href="/shop">Shop</Link>
      </nav>
      <div className="header-actions">
        <button aria-label="Search"><Search size={20}/></button>
        <button aria-label="Cart"><ShoppingBag size={20}/></button>
      </div>
    </header>
  );
}