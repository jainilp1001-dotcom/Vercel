import Link from "next/link";
import Image from "next/image";
import type { Product } from "../lib/shopify";

export default function ProductCard({ product }: { product: Product }) {
  const price = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: product.priceRange.minVariantPrice.currencyCode
  }).format(Number(product.priceRange.minVariantPrice.amount));

  return (
    <Link href={`/products/${product.handle}`} className="card">
      <div className="card-image">
        {product.featuredImage && (
          <Image
            src={product.featuredImage.url}
            alt={product.featuredImage.altText || product.title}
            fill
            sizes="(max-width: 700px) 50vw, 25vw"
          />
        )}
      </div>
      <div className="card-info">
        <h3>{product.title}</h3>
        <p>{price}</p>
      </div>
    </Link>
  );
}