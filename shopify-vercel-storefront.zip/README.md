# Shopify + Vercel storefront

This is a Next.js headless storefront designed to sit in front of an existing Shopify store.

## Setup
1. Add `SHOPIFY_STORE_DOMAIN` and `SHOPIFY_STOREFRONT_ACCESS_TOKEN` in Vercel Environment Variables.
2. Deploy.
3. The storefront reads products from Shopify and sends checkout/product purchases to Shopify.

The Shopify theme/store remains intact; this project is the customer-facing frontend.
